<?php
include '../../config/config.php';
include '../../config/ChromePhp.php';

$user_data = $_SESSION['user_data'];
ChromePhp::log('USER data:');
ChromePhp::log($_SESSION['user_data']);
$user_id = $_SESSION['user_id'];
$pet_data = $_SESSION['pet_data'];
ChromePhp::log('USER pets:');
ChromePhp::log($_SESSION['pet_data']);
$user_notifications = $_SESSION['user_notifications'];
ChromePhp::log('USER notifs:');
ChromePhp::log($_SESSION['user_notifications']);
?>

<!DOCTYPE html>
<html>
<head>
	<title>My Profile</title>
	<link rel="stylesheet" type="text/css" href="../styles.css">
	<link rel="stylesheet" type="text/css" href="uprofile.css">
	<link rel="stylesheet" type="text/css" href="uprofile.js">
	<link href="https://fonts.googleapis.com/css?family=Luckiest+Guy" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Concert+One" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Gamja+Flower" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Poor+Story" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Josefin+Sans" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Mali" rel="stylesheet">
</head>
<body>
	<div class="topnav">
		<a href='../registration/petreg.php'>Donate Pets</b></a>
		<a href='../adoption-list/adoption-list.controller.php?id=<?php echo $user_id ?>'>Adoption List</a>
		<a href='../index.php'>Log Out</b></a>

	</div>

	<div class="container">
		<div class="profile-section">
			<h1>MY PROFILE</h1>
			<div class="user-details">
				<div class="user-image">
					<img src="../../img/<?php echo $user_data['file_name'] ?>" alt="" width="100">
					<!-- <a href="#" class="adopt-button">CHANGE PICTURE</a> -->
				</div>
				<div class="edit">
					<button class="button button1" value="Submit">Save</button>
				</div>
				<style>
				input[type=text], select {
					width: 100%;
					padding: 12px 20px;
					margin: 8px 0;
					display: inline-block;
					border: 1px solid #ccc;
					border-radius: 4px;
					box-sizing: border-box;
				}

				input[type=submit] {
					width: 100%;
					background-color: #4CAF50;
					color: white;
					padding: 14px 20px;
					margin: 8px 0;
					border: none;
					border-radius: 4px;
					cursor: pointer;
				}

				input[type=submit]:hover {
					background-color: #45a049;
				}

				div {
					border-radius: 5px;
					background-color: #f2f2f2;
					padding: 20px;
				}
			</style>
			<div class="form">
				<form method="POST">
					<label for="fname">First Name</label>
					<input type="text" name="firstname"placeholder="Your name..">

					<label for="lname">Last Name</label>
					<input type="text" id="lname" name="lastname" placeholder="Your last name..">

					<label for="country">Country</label>
					<select id="country" name="country">
						<option value="australia">Australia</option>
						<option value="canada">Canada</option>
						<option value="usa">USA</option>
					</select>
				</form>
			</div>
		</div>
		<h1>MY PETS</h1>

		<div class="user-pets">

			<?php
			if(isset($pet_data) || empty($pet_data)) {
				foreach ($pet_data as $key => $value) {
					echo	'<div class="pet-card">';
					echo		'<div class="pet-image">';
					echo               '<img width="180" src="../../img/'.$value['file_name'].'">';
					echo		'</div>';
					echo		'<div class="pet-content">';
					echo			$value['petname'];
					echo			'<p>'.$value['breed'].'</p>';
					echo			'<div class="spacer"></div>';
					echo		'</div>';
					echo 	'</div>';
				}
			} else {
				echo "No Pets to show";
			}
			?>
		</div>
	</div>

	<div class="notification-section">
		<h1>NOTIFICATION</h1>

		<?php 
		if(isset($user_notifications)) {
			foreach ($user_notifications as $key => $value) {
				echo	'<div class="notif-card">';
				echo		'<div class="notif-image">';
				echo		'</div>';
				echo		'<div class="notif-info">';
				echo			'<div class="notif-name">';
				echo				$value['fname']." wants to adopt ".$value['petname'];
				echo			'</div>';
				echo			'<div class="spacer">';
				echo			'</div>';
				echo			'<a href="uprofile.controller.php?notifId='.$value['notif_id'].'" class="adopt-button">REVIEW</a>';
				echo		'</div>';
				echo	'</div>';
			}
		} else {
			echo "No notifications yet";
		}

		?>

	</div>
</div>

<button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModalHorizontal">
    Launch Horizontal Form
</button>

<!-- Modal -->
<div class="modal fade" id="myModalHorizontal" tabindex="-1" role="dialog" 
     aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <button type="button" class="close" 
                   data-dismiss="modal">
                       <span aria-hidden="true">&times;</span>
                       <span class="sr-only">Close</span>
                </button>
                <h4 class="modal-title" id="myModalLabel">
                    Modal title
                </h4>
            </div>
            
            <!-- Modal Body -->
            <div class="modal-body">
                
                <form class="form-horizontal" role="form">
                  <div class="form-group">
                    <label  class="col-sm-2 control-label"
                              for="inputEmail3">Email</label>
                    <div class="col-sm-10">
                        <input type="email" class="form-control" 
                        id="inputEmail3" placeholder="Email"/>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-2 control-label"
                          for="inputPassword3" >Password</label>
                    <div class="col-sm-10">
                        <input type="password" class="form-control"
                            id="inputPassword3" placeholder="Password"/>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <div class="checkbox">
                        <label>
                            <input type="checkbox"/> Remember me
                        </label>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <button type="submit" class="btn btn-default">Sign in</button>
                    </div>
                  </div>
                </form>
                
                
                
                
                
                
            </div>
            
            <!-- Modal Footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-default"
                        data-dismiss="modal">
                            Close
                </button>
                <button type="button" class="btn btn-primary">
                    Save changes
                </button>
            </div>
        </div>
    </div>
</div>




</body>
</html>